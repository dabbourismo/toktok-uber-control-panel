﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ElCaptain.Models.Enums
{
    public enum EnumOrderRefusalType
    {
        RefusedByClient,
        RefusedByDeliveryMan,
        Canceled
    }
}